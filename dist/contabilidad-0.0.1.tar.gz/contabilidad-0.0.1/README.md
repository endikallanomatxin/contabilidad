# contabilidad

El objetivo del paquete es hacer las tareas de contabilidad.

## Uso

Hay tres clases:

- El asiento
- El libro diario
- El libro mayor
- El balance

Los métodos que tiene cada uno son:

asiento.tabla()



## Dudas

- Como se hace el pyg
- Cuentas 300 vs 600 de mercaderias

Dudas para preguntar:

- Los negativos en la cuenta del pyg. ¿No habíamos quedado en que parentesis significaba negativo?
