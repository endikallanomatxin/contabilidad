# Dudas

- Como se hace el pyg
- Cuentas 300 vs 600 de mercaderias

Dudas para preguntar:
- ¿Es importante que queden agrupadas las operaciones del asiento contable para que pueda saberse que provienen del mismo asiento?
- Los negativos en la cuenta del pyg. ¿No habíamos quedado en que parentesis significaba negativo?